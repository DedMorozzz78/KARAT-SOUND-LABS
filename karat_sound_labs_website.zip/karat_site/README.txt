KARAT SOUND LABS — KARATONE

Это статический сайт. Главная страница: index.html

Структура:
index.html
models.html
families.html
history.html
about.html
models/*.html
assets/karat-logo.png
style.css
script.js

Для публикации нужен любой статический хостинг (например GitHub Pages). После загрузки содержимого папки корнем сайта должен быть index.html.
